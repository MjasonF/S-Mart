

<?php $__env->startSection('content'); ?>
<div class="container" style="background-color:rgb(139, 236, 110)">
    <div class="row justify-content-center">
        <div class="col-mx-8 text-center">
            <h3><b>Manage Categories</b></h3>
            <div class="cardset d-flex flex-wrap justify-content-center">
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card m-2 p-2" style="background-color:rgb(1, 170, 23)">
                        <img src="<?php echo e(asset("assets/$item->categoryimg")); ?>" style="width:350px;height:330px;"></br>
                        <div class="container">
                            <h4 style="color:black"><b><?php echo e($item->categoryname); ?></b></h4>
                        </div>
                        <div class="d-flex flex-row justify-content-center">
                            <form method="post" action="<?php echo e(route("deletecategory", $item->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <a href="/">
                                <button style="background-color:red;color:white">Delete Category</button>
                                </a>                                
                            </form>

                            <a href="/updatecategory/<?php echo e($item->id); ?>">
                            <button style="background-color:blue;color:white">Update Category</button>
                            </a>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mjason\projectWebProg\resources\views/managecategory.blade.php ENDPATH**/ ?>