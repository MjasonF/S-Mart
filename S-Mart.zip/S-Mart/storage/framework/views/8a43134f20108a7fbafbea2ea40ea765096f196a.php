

<?php $__env->startSection('content'); ?>
<div class="container" style="background-color:rgb(139, 236, 110)">
    <div class="row justify-content-center">
        <div class="col-mx-8 text-center">
            <h2><b><?php echo e($categories->categoryname); ?></b></h2></br>
            <form method="GET" action="/searchproduct/<?php echo e($categories->id); ?>">
                <div class="search text-left">
                    <select name="option" id="option">
                    <option value="name">Name</option>
                    <option value="price">Price</option>
                    </select>
                    <input name="search" type="search" placeholder="Search">
                    <button type="submit">Search</button>
                </div>
            </form>
            <div class="cardset d-flex flex-wrap">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/productdetail/<?php echo e($item->id); ?>">
                    <div class="card m-2 p-2" style="background-color:rgb(1, 170, 23)">
                        <img src="<?php echo e(asset("assets/$item->productimg")); ?>" style="width:300px;height:330px;"></br>
                        <div class="container">
                            <h4 style="color:black"><b><?php echo e($item->productname); ?></b></h4>
                            <h4 style="color:black">Rp. <?php echo e(number_format($item->productprice,2)); ?></h4>
                            <?php if(Auth::check() && Auth::user()->isManager==1): ?>
                            <div class="d-flex flex-row justify-content-center">
                                <form method="post" action="<?php echo e(route("deleteProduct", $item->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <a href="/">
                                    <button style="background-color:red;color:white">Delete Product</button>
                                    </a>                                
                                </form>

                                <a href="/updateproduct/<?php echo e($item->id); ?>">
                                <button style="background-color:blue;color:white">Update Product</button>
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div id="page">
        <?php echo e($products->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kuki9\Desktop\Project akhir\projectWebProg\resources\views/category.blade.php ENDPATH**/ ?>