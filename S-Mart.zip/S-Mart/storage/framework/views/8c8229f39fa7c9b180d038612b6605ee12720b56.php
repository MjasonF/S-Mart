

<?php $__env->startSection('content'); ?>
<div class="container" style="background-color:rgb(139, 236, 110)">
    <div class="row justify-content-center">
        <div class="col-mx-8 text-center">
            <h2><b>Your Transaction History</b></h2></br>
            <div>
                <?php if(count($sorted) > 0): ?>
                    <div class="cardset">
                        <?php $__currentLoopData = $sorted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="detaillink" href="/transactiondetail/<?php echo e($item->id); ?>">
                            <?php if(($loop->index+1) % 2 != 0): ?>
                                <div class="card col text-light" style="background-color: black"><b>Transaction at <?php echo e($item->created_at); ?></b></div>
                            <?php else: ?>
                                <div class="card col text-dark" style="background-color: white"><b>Transaction at <?php echo e($item->created_at); ?></b></div>
                            <?php endif; ?>
                            <br>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <h1 class="text-center">Transaction is empty</h1>
                <?php endif; ?>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mjason\projectWebProg\resources\views/transactionhistory.blade.php ENDPATH**/ ?>