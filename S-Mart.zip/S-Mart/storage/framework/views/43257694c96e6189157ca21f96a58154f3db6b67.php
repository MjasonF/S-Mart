

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <h3 class="text-center"><b>Your Cart</b></h3>

            <?php $__currentLoopData = $mycart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cardset d-flex flex-row" style="background-color: #dfe9ac">

                    <div class="col">
                        <img style="width:100px" src="/assets/<?php echo e($item->product->productimg); ?>">
                    </div>

                    <div class="col align-self-center">
                        <h3><b><?php echo e($item->product->productname); ?></b></h3>
                    </div>

                    <div class="col align-self-center">
                        <h3><b>Rp <?php echo e(number_format($item->product->productprice * $item->quantity,2)); ?></b></h3>
                    </div>
                    
                    <form method="POST" action="<?php echo e(route('updatecart')); ?>" class = "row">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                        <div class="col align-self-center">
                            <b>Quantity</b>
                            <input id='quantity' name='quantity' type="number" placeholder ="<?php echo e($item->quantity); ?>"> 
                        </div> 

                        <div class="form-group row mb-0">
                        <div class="col align-self-center">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Update')); ?>

                            </button>                          
                        </div>
                    </div>

                    </form>
                </div>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($mycart) != 0): ?>
            <form method="POST" action="<?php echo e(route('createtransaction')); ?>">
                <?php echo csrf_field(); ?>
                <div class="align-self-center text-center">
                    <a href="transactionhistory">
                        <button type="submit" class="btn btn-primary" style="background-color: #bfd58e">
                            <?php echo e(__('Checkout')); ?>

                        </button>
                    </a>
                </div>
            </form>
            <?php else: ?>
                <br>
                <br>
                <h1 class="text-center">Your Cart is empty</h1>
            <?php endif; ?>  
        </div>
    </div>
</div>

        <br><br>
            <div class="card p-3 m-2" style="background-color:#bfd58e">
                <footer class="text-muted" id="footer-container">
                <div class="row" id="footer-items-container">
                    <div class="">
                    <img src="<?php echo e(asset('/storage/img/material/Logo.png')); ?>" alt="">
                    </div>
                <div class="col-6 col-md">
                    <h6>Learn More</h6>

                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="#">About S-Mart</a></li>
                      <li><a class="text-muted" href="#">FAQs</a></li>
                      <li><a class="text-muted" href="#">Privacy Policy</a></li>
                      <li><a class="text-muted" href="#">Terms & Conditions</a></li>
                    </ul>
                  </div>
                  <div class="col-6 col-md">
                    <h6>Contact Us</h6>
                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="#">Marcellinus Jason</a></li>
                      <li><a class="text-muted" href="#">+62 81295167818</a></li>

                    </ul>
                  </div>
                  <div class="col-6 col-md">
                  <h6>Our Social Media</h6>
                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="https://www.instagram.com/kmgsmartt/">Instagram</a></li>
                      <li><a class="text-muted" href="https://www.facebook.com/s.mart.7505468">Facebook</a></li>
                      <li><a class="text-muted" href="https://twitter.com/kmgsmart">Twitter</a></li>
                    </ul>
                  </div>
                </div>
                <div class="footer-copyright text-center py-3" style="color: black;">© 2021 Copyright:
                    <a href="/" style="color: black;">S-Mart</a>
                  </div>
            </footer>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mjason\Downloads\S-Mart\S-Mart\resources\views/cart.blade.php ENDPATH**/ ?>