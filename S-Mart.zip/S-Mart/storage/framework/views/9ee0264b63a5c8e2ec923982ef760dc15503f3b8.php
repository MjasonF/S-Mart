

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-mx-8">
            <h2 class="text-center"><b>Your Transaction at <?php echo e($transactions->created_at); ?></b></h2></br>
            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="background-color:#bfd58e">
                    <div class="row">
                        <div class="col-sm-5 d-flex align-items-center">
                            <img class="card-img" style="height:70%; width:70%; align-content: center" src="/assets/<?php echo e($item->products->productimg); ?>">
                        </div>
                        <div class="col-sm">
                            <div class="card-body">
                                <h3><?php echo e($item->products->productname); ?></h3>
                                <div class="mt-2">Rp. <?php echo e(number_format($item->products->productprice,2)); ?></div>
                                <div class="mt-2">Quantity : <?php echo e($item->quantity); ?></div>
                                <div class="mt-2">Sub Total : Rp. <?php echo e(number_format($item->quantity * $item->products->productprice,2)); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div style="font-size: 25px">
                <b>Total Price : Rp. <?php echo e(number_format($totalprice,2)); ?></b>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\S-Mart\resources\views/transactiondetail.blade.php ENDPATH**/ ?>