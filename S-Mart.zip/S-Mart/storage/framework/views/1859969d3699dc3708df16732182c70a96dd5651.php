

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 d-flex flex-row">
            <img src="/assets/<?php echo e($products->productimg); ?>" style="width:300px;height:330px;">
            <div class="col-md-8 d-flex flex-column">
                <div class="m-2">
                    <h3><?php echo e($products->productname); ?></h3></br>
                    <h3>Rp. <?php echo e(number_format($products->productprice,2)); ?></h3></br>
                    <h4><?php echo e($products->description); ?></h3></br>
                    <?php if(Auth::check() && Auth::user()->isManager==0): ?>
                    <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('addtocart', $products->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="column">
                            <div class="form-group row">
                            <label for="quantity" class="col-md-2 col-form-label"><?php echo e(__('Quantity')); ?></label>
                                <div class="col-md-6">
                                    <input id="quantity" type="number" class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="quantity" value="<?php echo e(old('quantity')); ?>" required autocomplete="quantity">
                                    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Add to Cart')); ?>

                            </button>
                        </div>
                    </form>
                    <?php elseif(Auth::check() && Auth::user()->isManager==1): ?>
                    <?php else: ?>
                    <div class="column">
                        <div class="form-group row">
                        <label for="quantity" class="col-md-2 col-form-label"><?php echo e(__('Quantity')); ?></label>
                            <div class="col-md-6">
                                <input id="quantity" type="number" class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="quantity" value="<?php echo e(old('quantity')); ?>" required autocomplete="quantity">
                                <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <a href="<?php echo e(route('login')); ?>">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Add to Cart')); ?>

                            </button>
                        </a>
                    </div>
                    
                    <?php endif; ?>
                </div>                 
            </div>

        </div>
        
    </div>
    
    <br><br>
    <div class="card p-2" style="background-color:#bfd58e">
        <footer class="text-muted" id="footer-container">
        <div class="row" id="footer-items-container">
            <div class="">
            <img src="<?php echo e(asset('/storage/img/material/Logo.png')); ?>" alt="">
            </div>
        <div class="col-5 col-md">
            <h6>Learn More</h6>

            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">About S-Mart</a></li>
              <li><a class="text-muted" href="#">FAQs</a></li>
              <li><a class="text-muted" href="#">Privacy Policy</a></li>
              <li><a class="text-muted" href="#">Terms & Conditions</a></li>
            </ul>
          </div>
          <div class="col-5 col-md">
            <h6>Contact Us</h6>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">Marcellinus Jason</a></li>
              <li><a class="text-muted" href="#">+62 81295167818</a></li>

            </ul>
          </div>
          <div class="col-5 col-md">
          <h6>Our Social Media</h6>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="https://www.instagram.com/kmgsmartt/">Instagram</a></li>
              <li><a class="text-muted" href="https://www.facebook.com/s.mart.7505468">Facebook</a></li>
              <li><a class="text-muted" href="https://twitter.com/kmgsmart">Twitter</a></li>
            </ul>
          </div>
        </div>
        <div class="footer-copyright text-center py-3" style="color: black;">© 2021 Copyright:
            <a href="/" style="color: black;">S-Mart</a>
          </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mjason\Downloads\S-Mart\S-Mart\resources\views/productdetail.blade.php ENDPATH**/ ?>