<?php $__env->startSection('content'); ?>
<div class="container" style="background-color:rgb(139, 236, 110)">
    <div class="row justify-content-center">
        <div class="col-mx-8 text-center">
            <h2><b>Welcome to S-Mart</b></h2></br>
            <h3><b>"Buy Smart Sell Smart"</b></h3>
            <div class="cardset d-flex flex-wrap justify-content-center">
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class ="catlink" href="/category/<?php echo e($item->id); ?>">
                    <div class="card m-2 p-2" style="background-color:rgb(1, 170, 23)">
                        <img src="<?php echo e(asset("assets/$item->categoryimg")); ?>" style="width:350px;height:330px;"></br>
                        <div class="container">
                            <h4 style="color:black"><b><?php echo e($item->categoryname); ?></b></h4>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <footer>
                <a href="https://www.instagram.com" >
                <img class="pic" src = "/assets/instagram.jpg"> </a>
            </footer>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\COMP6144 - Web Programming\S-Mart\resources\views/home.blade.php ENDPATH**/ ?>