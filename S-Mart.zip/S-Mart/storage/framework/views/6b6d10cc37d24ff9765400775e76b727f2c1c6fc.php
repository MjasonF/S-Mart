<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-mx-8 text-center">
            <h2><b>Welcome to S-Mart</b></h2></br>
            <h3><b>"Buy Smart Sell Smart"</b></h3>

            <div class="d-flex flex-row justify-content-center">
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class ="catlink" href="/category/<?php echo e($item->id); ?>">
                    <div class="card m-2 p-2" style="background-color:#bfd58e">
                        <img src="<?php echo e(asset("assets/$item->categoryimg")); ?>" style="width:350px;height:330px;"></br>
                        <div class="container">
                            <h4 style="color:black"><b><?php echo e($item->categoryname); ?></b></h4>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            

            <br><br>
            <div class="card p-2" style="background-color:#bfd58e">
                <footer class="text-muted" id="footer-container">
                <div class="row" id="footer-items-container">
                    <div class="">
                    <img src="<?php echo e(asset('/storage/img/material/Logo.png')); ?>" alt="">
                    </div>
                <div class="col-5 col-md">
                    <h6>Learn More</h6>

                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="#">About S-Mart</a></li>
                      <li><a class="text-muted" href="#">FAQs</a></li>
                      <li><a class="text-muted" href="#">Privacy Policy</a></li>
                      <li><a class="text-muted" href="#">Terms & Conditions</a></li>
                    </ul>
                  </div>
                  <div class="col-5 col-md">
                    <h6>Contact Us</h6>
                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="#">Marcellinus Jason</a></li>
                      <li><a class="text-muted" href="#">+62 81295167818</a></li>

                    </ul>
                  </div>
                  <div class="col-5 col-md">
                  <h6>Our Social Media</h6>
                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="https://www.instagram.com/kmgsmartt/">Instagram</a></li>
                      <li><a class="text-muted" href="https://www.facebook.com/s.mart.7505468">Facebook</a></li>
                      <li><a class="text-muted" href="https://twitter.com/kmgsmart">Twitter</a></li>
                    </ul>
                  </div>
                </div>
                <div class="footer-copyright text-center py-3" style="color: black;">© 2021 Copyright:
                    <a href="/" style="color: black;">S-Mart</a>
                  </div>
            </footer>
        </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\S-Mart\resources\views/home.blade.php ENDPATH**/ ?>