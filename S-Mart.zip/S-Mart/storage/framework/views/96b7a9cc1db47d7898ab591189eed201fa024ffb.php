
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-center">
                <div class="card-header">Change Password</div>
   
                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('changepass')); ?>">
                        <?php echo e(csrf_field()); ?> 
                        <div class="form-group row<?php echo e($errors->has('currentpassword') ? ' has-error' : ''); ?>">
                            <label for="newpassword" class="col-md-4 col-form-label text-md-right">Your Password</label>
                            <div class="col-md-6">
                                <input id="currentpassword" type="password" class="form-control" name="currentpassword" required>
                                <?php if($errors->has('currentpassword')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('currentpassword')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                                 
                        <div class="form-group row<?php echo e($errors->has('newpassword') ? ' has-error' : ''); ?>">
                            <label for="newpassword" class="col-md-4 col-form-label text-md-right">New Password</label>     
                            <div class="col-md-6">
                                <input id="newpassword" type="password" class="form-control" name="newpassword" required>
                                <?php if($errors->has('newpassword')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('newpassword')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                                 
                        <div class="form-group row">
                            <label for="newconfirm" class="col-md-4 col-form-label text-md-right">Confirm New Password</label> 
                            <div class="col-md-6">
                                <input id="newconfirm" type="password" class="form-control" name="newconfirm" required>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                Change Password
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>      
<?php $__env->stopSection(); ?>
                     
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mjason\projectWebProg\resources\views/changepassword.blade.php ENDPATH**/ ?>