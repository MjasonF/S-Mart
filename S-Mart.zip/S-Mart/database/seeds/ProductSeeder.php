<?php

use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([
            'categories_id' => '1',
            'productname' => 'Alpukat',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'buah-alpukat.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '1',
            'productname' => 'Anggur',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'buah-Anggur.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '1',
            'productname' => 'Apel',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'buah-Apel.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '1',
            'productname' => 'Durian',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'buah-Durian.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '1',
            'productname' => 'Lemon',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'buah-Lemon.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '1',
            'productname' => 'Mangga',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'buah-Mangga.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '1',
            'productname' => 'Naga',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'buah-Naga.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '1',
            'productname' => 'Rambutan',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'buah-Rambutan.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '2',
            'productname' => 'Bok Choy',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'bok choy.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '2',
            'productname' => 'Kangkung',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'kangkung.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '2',
            'productname' => 'Kailan',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'kailan.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '2',
            'productname' => 'Kangung',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'kentang.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '2',
            'productname' => 'Seledri',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'seledri.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '2',
            'productname' => 'Tauge',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'toge.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '2',
            'productname' => 'Tomat',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'tomat.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '2',
            'productname' => 'Wortel',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'wortel.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '3',
            'productname' => 'Daging Ayam',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'daging-ayam.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '3',
            'productname' => 'Daging Sapi',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'daging-sapi.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '3',
            'productname' => 'Daging Kambing',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'daging-kambing.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '3',
            'productname' => 'Daging Babi',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'daging-babi.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '4',
            'productname' => 'Beras',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'beras.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '4',
            'productname' => 'Minyak',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'minyak goreng.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '4',
            'productname' => 'Gula',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'gulaa.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '4',
            'productname' => 'Garam',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'garam.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '4',
            'productname' => 'Susu',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'susu.jpg'
        ]);

        DB::table('products')->insert([
            'categories_id' => '4',
            'productname' => 'Telur ayam',
            'productprice' => '100000',
            'description' => 'Product description blablabla',
            'productimg' => 'telur.jpg'
        ]);

    }
}
