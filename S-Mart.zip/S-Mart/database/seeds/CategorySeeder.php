<?php

use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert([
            'categoryname' => 'Buah-Buahan',
            'categoryimg' => 'buah-buah.jpg'
        ]);

        DB::table('categories')->insert([
            'categoryname' => 'Sayur-sayuran',
            'categoryimg' => 'sayur-sayur.jpg'
        ]);

        DB::table('categories')->insert([
            'categoryname' => 'Daging-dagingan',
            'categoryimg' => 'daging-dagingan.jpg'
        ]);

        DB::table('categories')->insert([
            'categoryname' => 'Sembako',
            'categoryimg' => 'sembako.jpg'
        ]);
    }
}
