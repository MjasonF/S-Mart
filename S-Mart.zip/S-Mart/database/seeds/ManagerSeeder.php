<?php

use Illuminate\Database\Seeder;

class ManagerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'username' => 'Manager',
            'email' => 'Manager@gmail.com',
            'password' => Hash::make('Manager123'),
            'address' => 'Manager Street',
            'gender' => 'Male',
            'dob' => '1212-12-12',
            'isManager' => '1'
        ]);

        DB::table('users')->insert([
            'username' => 'Mjason',
            'email' => 'mjason@gmail.com',
            'password' => Hash::make('mjason123'),
            'address' => 'Mjason Street',
            'gender' => 'Male',
            'dob' => '1212-12-12',
            'isManager' => '0'
        ]);
    }
}
