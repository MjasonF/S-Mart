@extends('layouts.app')

@section('content')
<div class="container" style="background-color:rgb(139, 236, 110)">
    <div class="row justify-content-center">
        <div class="col-mx-8 text-center">
            <h3><b>Manage Categories</b></h3>
            <div class="cardset d-flex flex-wrap justify-content-center">
            @foreach($list as $item)
                    <div class="card m-2 p-2" style="background-color:rgb(1, 170, 23)">
                        <img src="{{asset("assets/$item->categoryimg")}}" style="width:350px;height:330px;"></br>
                        <div class="container">
                            <h4 style="color:black"><b>{{$item->categoryname}}</b></h4>
                        </div>
                        <div class="d-flex flex-row justify-content-center">
                            <form method="post" action="{{route("deletecategory", $item->id)}}">
                                @csrf
                                <a href="/">
                                <button style="background-color:red;color:white">Delete Category</button>
                                </a>                                
                            </form>

                            <a href="/updatecategory/{{$item->id}}">
                            <button style="background-color:blue;color:white">Update Category</button>
                            </a>
                        </div>
                    </div>
            @endforeach
            </div>
        </div>
    </div>
</div>
@endsection