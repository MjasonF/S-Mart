@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 d-flex flex-row">
            <img src="/assets/{{$products->productimg}}" style="width:300px;height:330px;">
            <div class="col-md-8">
                <form method="POST" enctype="multipart/form-data" action="{{ route('update', $products->id) }}">
                    @csrf
                    <div class="form-group row">
                        <label for="category" class="col-md-4 col-form-label text-md-right">Category</label>
                        <div class="col-md-6">
                            <select name="category" id="category">
                                @foreach($list as $item)
                                    <option value="{{$item->categoryname}}">{{$item->categoryname}}</option>                           
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="productname" class="col-md-4 col-form-label text-md-right">{{ __('Product Name') }}</label>

                        <div class="col-md-6">
                            <input id="productname" type="text" class="form-control @error('productname') is-invalid @enderror" name="productname" value="{{ old('productname') }}" required autocomplete="productname" autofocus>

                            @error('productname')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="productprice" class="col-md-4 col-form-label text-md-right">{{ __('Product Price') }}</label>

                        <div class="col-md-6">
                            <input id="productprice" type="number" class="form-control @error('productprice') is-invalid @enderror" name="productprice" value="{{ old('productprice') }}" required autocomplete="productprice">

                            @error('productprice')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="description" class="col-md-4 col-form-label text-md-right">{{ __('Description') }}</label>

                        <div class="col-md-5">
                            <input id="description" type="text" placeholder="Description" class="@error('description') is-invalid @enderror" name="description" required>
                        
                            @error('description')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="productimg" class="col-md-4 col-form-label text-md-right">{{ __('Product Image') }}</label>

                        <div class="col-md-6">
                            <input id="productimg" type="file" class="@error('productimg') is-invalid @enderror" name="productimg" value="/storage/{{$products->productimg}}">

                            @error('productimg')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                {{ __('Update') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection