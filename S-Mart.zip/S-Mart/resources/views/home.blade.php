@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-mx-8 text-center">
            <h2><b>Welcome to S-Mart</b></h2></br>
            <h3><b>"Buy Smart Sell Smart"</b></h3>

            <div class="d-flex flex-row justify-content-center">
            @foreach($list as $item)
                <a class ="catlink" href="/category/{{$item->id}}">
                    <div class="card m-2 p-2" style="background-color:#bfd58e">
                        <img src="{{asset("assets/$item->categoryimg")}}" style="width:350px;height:330px;"></br>
                        <div class="container">
                            <h4 style="color:black"><b>{{$item->categoryname}}</b></h4>
                        </div>
                    </div>
                </a>
            @endforeach
            </div>

            {{-- <footer>
                <a href="https://www.instagram.com" >
                <img class="pic" src = "/assets/instagram.jpg"> </a>
            </footer> --}}

            <br><br>
            <div class="card p-2" style="background-color:#bfd58e">
                <footer class="text-muted" id="footer-container">
                <div class="row" id="footer-items-container">
                    <div class="">
                    <img src="{{ asset('/storage/img/material/Logo.png') }}" alt="">
                    </div>
                <div class="col-5 col-md">
                    <h6>Learn More</h6>

                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="#">About S-Mart</a></li>
                      <li><a class="text-muted" href="#">FAQs</a></li>
                      <li><a class="text-muted" href="#">Privacy Policy</a></li>
                      <li><a class="text-muted" href="#">Terms & Conditions</a></li>
                    </ul>
                  </div>
                  <div class="col-5 col-md">
                    <h6>Contact Us</h6>
                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="#">Marcellinus Jason</a></li>
                      <li><a class="text-muted" href="#">+62 81295167818</a></li>

                    </ul>
                  </div>
                  <div class="col-5 col-md">
                  <h6>Our Social Media</h6>
                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="https://www.instagram.com/kmgsmartt/">Instagram</a></li>
                      <li><a class="text-muted" href="https://www.facebook.com/s.mart.7505468">Facebook</a></li>
                      <li><a class="text-muted" href="https://twitter.com/kmgsmart">Twitter</a></li>
                    </ul>
                  </div>
                </div>
                <div class="footer-copyright text-center py-3" style="color: black;">© 2021 Copyright:
                    <a href="/" style="color: black;">S-Mart</a>
                  </div>
            </footer>
        </div>
            
        </div>
    </div>
</div>
@endsection
