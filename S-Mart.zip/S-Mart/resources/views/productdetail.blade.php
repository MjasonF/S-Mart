@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 d-flex flex-row">
            <img src="/assets/{{$products->productimg}}" style="width:300px;height:330px;">
            <div class="col-md-8 d-flex flex-column">
                <div class="m-2">
                    <h3>{{$products->productname}}</h3></br>
                    <h3>Rp. {{number_format($products->productprice,2)}}</h3></br>
                    <h4>{{$products->description}}</h3></br>
                    @if(Auth::check() && Auth::user()->isManager==0)
                    <form method="POST" enctype="multipart/form-data" action="{{ route('addtocart', $products->id) }}">
                        @csrf
                        <div class="column">
                            <div class="form-group row">
                            <label for="quantity" class="col-md-2 col-form-label">{{ __('Quantity') }}</label>
                                <div class="col-md-6">
                                    <input id="quantity" type="number" class="form-control @error('quantity') is-invalid @enderror" name="quantity" value="{{ old('quantity') }}" required autocomplete="quantity">
                                    @error('quantity')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                {{ __('Add to Cart') }}
                            </button>
                        </div>
                    </form>
                    @elseif(Auth::check() && Auth::user()->isManager==1)
                    @else
                    <div class="column">
                        <div class="form-group row">
                        <label for="quantity" class="col-md-2 col-form-label">{{ __('Quantity') }}</label>
                            <div class="col-md-6">
                                <input id="quantity" type="number" class="form-control @error('quantity') is-invalid @enderror" name="quantity" value="{{ old('quantity') }}" required autocomplete="quantity">
                                @error('quantity')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <a href="{{ route('login') }}">
                            <button type="submit" class="btn btn-primary">
                                {{ __('Add to Cart') }}
                            </button>
                        </a>
                    </div>
                    
                    @endif
                </div>                 
            </div>

        </div>
        
    </div>
    
    <br><br>
    <div class="card p-2" style="background-color:#bfd58e">
        <footer class="text-muted" id="footer-container">
        <div class="row" id="footer-items-container">
            <div class="">
            <img src="{{ asset('/storage/img/material/Logo.png') }}" alt="">
            </div>
        <div class="col-5 col-md">
            <h6>Learn More</h6>

            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">About S-Mart</a></li>
              <li><a class="text-muted" href="#">FAQs</a></li>
              <li><a class="text-muted" href="#">Privacy Policy</a></li>
              <li><a class="text-muted" href="#">Terms & Conditions</a></li>
            </ul>
          </div>
          <div class="col-5 col-md">
            <h6>Contact Us</h6>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">Marcellinus Jason</a></li>
              <li><a class="text-muted" href="#">+62 81295167818</a></li>

            </ul>
          </div>
          <div class="col-5 col-md">
          <h6>Our Social Media</h6>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="https://www.instagram.com/kmgsmartt/">Instagram</a></li>
              <li><a class="text-muted" href="https://www.facebook.com/s.mart.7505468">Facebook</a></li>
              <li><a class="text-muted" href="https://twitter.com/kmgsmart">Twitter</a></li>
            </ul>
          </div>
        </div>
        <div class="footer-copyright text-center py-3" style="color: black;">© 2021 Copyright:
            <a href="/" style="color: black;">S-Mart</a>
          </div>
    </footer>
</div>
@endsection