@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 d-flex flex-row">
            <img src="/assets/{{$lists->categoryimg}}" style="width:300px;height:330px;">
            <div class="col-md-8">
                <form method="POST" enctype="multipart/form-data" action="{{ route('updatecat', $lists->id) }}">
                    @csrf
                    <div class="form-group row">
                        <label for="categoryname" class="col-md-4 col-form-label text-md-right">{{ __('Category Name') }}</label>

                        <div class="col-md-6">
                            <input id="categoryname" type="text" class="form-control @error('categoryname') is-invalid @enderror" name="categoryname" value="{{ old('categoryname') }}" required autocomplete="categoryname" autofocus>

                            @error('categoryname')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="categoryimg" class="col-md-4 col-form-label text-md-right">{{ __('Category Image') }}</label>

                        <div class="col-md-6">
                            <input id="categoryimg" type="file" class="@error('categoryimg') is-invalid @enderror" name="categoryimg">

                            @error('categoryimg')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                {{ __('Update') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection