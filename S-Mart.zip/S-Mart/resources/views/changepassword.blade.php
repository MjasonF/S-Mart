@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-center">
                <div class="card-header">Change Password</div>
   
                <div class="card-body">
                    @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif
                    <form method="POST" action="{{ route('changepass') }}">
                        {{ csrf_field() }} 
                        <div class="form-group row{{ $errors->has('currentpassword') ? ' has-error' : '' }}">
                            <label for="newpassword" class="col-md-4 col-form-label text-md-right">Your Password</label>
                            <div class="col-md-6">
                                <input id="currentpassword" type="password" class="form-control" name="currentpassword" required>
                                @if ($errors->has('currentpassword'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('currentpassword') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                                 
                        <div class="form-group row{{ $errors->has('newpassword') ? ' has-error' : '' }}">
                            <label for="newpassword" class="col-md-4 col-form-label text-md-right">New Password</label>     
                            <div class="col-md-6">
                                <input id="newpassword" type="password" class="form-control" name="newpassword" required>
                                @if ($errors->has('newpassword'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('newpassword') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                                 
                        <div class="form-group row">
                            <label for="newconfirm" class="col-md-4 col-form-label text-md-right">Confirm New Password</label> 
                            <div class="col-md-6">
                                <input id="newconfirm" type="password" class="form-control" name="newconfirm" required>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                Change Password
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>      
@endsection
                     