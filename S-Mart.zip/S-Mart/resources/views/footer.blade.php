<!-- <footer class="footer font-small">
  <div class="container">
    <a class="navbar-brand" href="{{ url('/') }}" id="brand-footer">
      
    </a>

  </div>
</footer> -->
<footer class="text-muted" id="footer-container">
    <div class="row" id="footer-items-container">
      <div class="col-6 col-md">
        <img src="{{ asset('/storage/img/material/Logo.png') }}" alt="">
      </div>
      <div class="col-6 col-md">
        <h6>Learn More</h6>
        <ul class="list-unstyled text-small">
          <li><a class="text-muted" href="#">About Footoo</a></li>
          <li><a class="text-muted" href="#">FAQs</a></li>
          <li><a class="text-muted" href="#">Privacy Policy</a></li>
          <li><a class="text-muted" href="#">Terms & Conditions</a></li>
        </ul>
      </div>
      <div class="col-6 col-md">
        <h6>Contact Us</h6>
        <ul class="list-unstyled text-small">
          <li><a class="text-muted" href="#">marketing.footoo@gmail.com</a></li>
          <li><a class="text-muted" href="#">(021) 123456</a></li>
          <li><a class="text-muted" href="#">(021) 123457</a></li>
        </ul>
      </div>
      <div class="col-6 col-md">
      <h6>Our Social Media</h6>
        <ul class="list-unstyled text-small">
          <li><a class="text-muted" href="#">Instagram</a></li>
          <li><a class="text-muted" href="#">Facebook</a></li>
          <li><a class="text-muted" href="#">Twitter</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-copyright text-center py-3" style="color: white;">© 2021 Copyright:
        <a href="/" style="color: white;">Footoo</a>
      </div>
</footer>
