@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-mx-8 text-center">
            <h2><b>{{$categories->categoryname}}</b></h2></br>
            <form method="GET" action="/searchproduct/{{$categories->id}}">
                <div class="search text-left">
                    <select name="option" id="option">
                    <option value="name">Name</option>
                    <option value="price">Price</option>
                    </select>
                    <input name="search" type="search" placeholder="Search">
                    <button type="submit">Search</button>
                </div>
            </form>
            <div class="cardset d-flex flex-wrap">
                @foreach($products as $item)
                <a href="/productdetail/{{$item->id}}">
                    <div class="card m-2 p-2" style="background-color:#bfd58e">
                        <img src="{{asset("assets/$item->productimg")}}" style="width:300px;height:330px;"></br>
                        <div class="container">
                            <h4 style="color:black"><b>{{$item->productname}}</b></h4>
                            <h4 style="color:black">Rp. {{number_format($item->productprice,2)}}</h4>
                            @if(Auth::check() && Auth::user()->isManager==1)
                            <div class="d-flex flex-row justify-content-center">
                                <form method="post" action="{{route("deleteProduct", $item->id)}}">
                                    @csrf
                                    <a href="/">
                                    <button style="background-color:red;color:white">Delete Product</button>
                                    </a>                                
                                </form>

                                <a href="/updateproduct/{{$item->id}}">
                                <button style="background-color:blue;color:white">Update Product</button>
                                </a>
                            </div>
                            @endif
                        </div>
                    </div>
                </a>
                @endforeach

                
            </div>
            <br><br>
            <div class="card p-2" style="background-color:#bfd58e">
                <footer class="text-muted" id="footer-container">
                <div class="row" id="footer-items-container">
                    <div class="">
                    <img src="{{ asset('/storage/img/material/Logo.png') }}" alt="">
                    </div>
                <div class="col-5 col-md">
                    <h6>Learn More</h6>
        
                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="#">About S-Mart</a></li>
                      <li><a class="text-muted" href="#">FAQs</a></li>
                      <li><a class="text-muted" href="#">Privacy Policy</a></li>
                      <li><a class="text-muted" href="#">Terms & Conditions</a></li>
                    </ul>
                  </div>
                  <div class="col-5 col-md">
                    <h6>Contact Us</h6>
                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="#">Marcellinus Jason</a></li>
                      <li><a class="text-muted" href="#">+62 81295167818</a></li>
        
                    </ul>
                  </div>
                  <div class="col-5 col-md">
                  <h6>Our Social Media</h6>
                    <ul class="list-unstyled text-small">
                      <li><a class="text-muted" href="https://www.instagram.com/kmgsmartt/">Instagram</a></li>
                      <li><a class="text-muted" href="https://www.facebook.com/s.mart.7505468">Facebook</a></li>
                      <li><a class="text-muted" href="https://twitter.com/kmgsmart">Twitter</a></li>
                    </ul>
                  </div>
                </div>
                <div class="footer-copyright text-center py-3" style="color: black;">© 2021 Copyright:
                    <a href="/" style="color: black;">S-Mart</a>
                  </div>
            </footer>
        </div>
        </div>
    </div>
    <div id="page">
        {{$products->links()}}
    </div>
</div>
@endsection