@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-mx-8">
            <h2 class="text-center"><b>Your Transaction at {{ $transactions->created_at }}</b></h2></br>
            @foreach($details as $item)
                <div class="card" style="background-color:#bfd58e">
                    <div class="row">
                        <div class="col-sm-5 d-flex align-items-center">
                            <img class="card-img" style="height:70%; width:70%; align-content: center" src="/assets/{{$item->products->productimg}}">
                        </div>
                        <div class="col-sm">
                            <div class="card-body">
                                <h3>{{ $item->products->productname }}</h3>
                                <div class="mt-2">Rp. {{ number_format($item->products->productprice,2) }}</div>
                                <div class="mt-2">Quantity : {{ $item->quantity }}</div>
                                <div class="mt-2">Sub Total : Rp. {{ number_format($item->quantity * $item->products->productprice,2) }}</div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
            @endforeach
            <div style="font-size: 25px">
                <b>Total Price : Rp. {{number_format($totalprice,2)}}</b>

            </div>
        </div>
    </div>
</div>
@endsection