@extends('layouts.app')

@section('content')
<div class="container" >
    <div class="row justify-content-center">
        <div class="col-mx-8 text-center">
            <h2><b>Your Transaction History</b></h2></br>
            <div>
                @if (count($sorted) > 0)
                    <div class="cardset">
                        @foreach($sorted as $item)
                            <a class="detaillink" href="/transactiondetail/{{ $item->id }}">
                            @if (($loop->index+1) % 2 != 0)
                                <div class="card col text-light" style="background-color: black"><b>Transaction at {{ $item->created_at }}</b></div>
                            @else
                                <div class="card col text-dark" style="background-color: white"><b>Transaction at {{ $item->created_at }}</b></div>
                            @endif
                            <br>
                            </a>
                        @endforeach
                    </div>
                @else
                    <h1 class="text-center">Transaction is empty</h1>
                @endif
            </div>
            
        </div>
    </div>
</div>
@endsection
