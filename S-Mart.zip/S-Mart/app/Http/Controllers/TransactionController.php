<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\Transaction;
use App\TransactionDetail;

class TransactionController extends Controller
{
    public function transactionhistory(){
        $users_id = Auth::id();
        $transactions = User::find($users_id)->transactions;
        $sorted = $transactions->sortByDesc('created_at');
        $sorted->all();
        return view('transactionhistory')->with('sorted', $sorted);
        //menampilkan view transactionhistory berdasarkan data terbaru yang di sort berdasarkan variabel "created_at"
    }

    public function createtransaction(Request $request)
    {
        $users_id = Auth::id();
        $cart = User::find($users_id)->carts;
        $transaction = new Transaction;
        $transaction->users_id = Auth::id();
        $transaction->save();
        //membuat transaction baru
        foreach($cart as $carts) 
        {
            $detail = new TransactionDetail;
            $detail->transactions_id = $transaction->id;
            $detail->products_id = $carts->products_id;
            $detail->quantity = $carts->quantity;
            $detail->save();
            //membuat transaction detail baru
            $carts->delete();
            //delete data pada cart
        }
        
        return redirect('/')->with('success', 'Checkout success');
        //memindahkan seluruh data di cart ke transaction dan transaction detail
    }

    public function transactiondetail($id) {
        $details = Transaction::find($id)->detail;
        $users_id = Auth::id();
        $transactions = Transaction::find($id);
        $totalprice = 0;
        foreach($details as $item)
        {
            $totalprice += $item->quantity * $item->products->productprice;
            //mendapatkan nilai total price dengan menjumlahkan seluruh nilai subtotal
        }
        
        return view('transactiondetail')->with('details', $details)->with('transactions', $transactions)->with('totalprice', $totalprice);
        //menampilkan view transactiondetail
    }
}
