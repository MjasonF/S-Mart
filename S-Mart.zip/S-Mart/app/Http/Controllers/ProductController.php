<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Category;
use App\Product;

class ProductController extends Controller
{
    public function inputProduct(Request $data)
    {
        $this->validate($data, [
            'category' => ['required'],
            'productname' => ['required', 'string', 'min:5', 'unique:products'],
            'productprice' => ['required', 'integer', 'min:50000'],
            'description' => ['required', 'string', 'min:20'],
            'productimg' => ['required']
            //validasi data yang akan diinput untuk menambahkan product baru
        ]);
        $file = $data['productimg'];
        $filename = $file->getClientOriginalName();
        //mengubah nama gambar menjadi nama asli gambar sehingga ketika disimpan ke dalam database data yang masuk adalah nama gambar yang sesungguhnya
        $path = $file->move('assets/',$filename);
        //memasukkan gambar yang diinput ke dalam storage laravel
        $item = new Product;
        $cat = Category::where('categoryname',$data['category'])->first();
        $item->categories_id = $cat->id;
        $item->productname = $data['productname'];
        $item->productprice = $data['productprice'];
        $item->description = $data['description'];
        $item->productimg = $filename;
        $item->save();
        return redirect("/addproduct");
        //menambahkan product baru ke dalam category yang dipilih berdasarkan data yang telat diinput
    }

    public function addProduct()
    {
        $list = Category::all();
        return view('addproduct')->with('list', $list);
        //menampilkan view addproduct
    }

    public function searchproduct(Request $request, $id)
    {
        $categories=Category::where('id',$id)->first();
        if($request->option=='name'){
            if($request->search == NULL)
            {
                return redirect("category/$id");
            }
            else
            {
                $products = DB::table('products')->where([['productname','like',"%".$request->search."%"], ['categories_id', $id],])->paginate(8);
            }
            //apabila data nama product yang telah diinput user sesuai dengan data yang ada pada database 
            //atau data nama product yang diinput user memiliki kesamaan huruf atau karakter secara berurutan
            //menampilkan product yang sesuai dengan data tersebut
        }else{
            if($request->search == NULL)
            {
                return redirect("category/$id");
            }
            else
            {
                $products = DB::table('products')->where([['productprice','like',$request->search], ['categories_id', $id],])->paginate(8);
            }
            //apabila data harga product yang telah diinput user sesuai dengan data yang ada pada database
            //menampilkan product yang sesuai dengan data tersebut
        }
        return view('category')->with('categories', $categories)->with('products',$products);
    }

    public function update(Request $data, $id)
    {
        $this->validate($data, [
            'category' => ['required'],
            'productname' => ['required', 'string', 'min:5', 'unique:products'],
            'productprice' => ['required', 'integer', 'min:50000'],
            'description' => ['required', 'string', 'min:20'],
            //validasi data yang akan diinput untuk mengubah data pada product
        ]);
        $item = Product::find($id);
        $cat = Category::where('categoryname',$data['category'])->first();
        $item->categories_id = $cat->id;
        $item->productname = $data['productname'];
        $item->productprice = $data['productprice'];
        $item->description = $data['description'];
        if ($data['productimg'] != NULL)
        {
            $file = $data['productimg'];
            $filename = $file->getClientOriginalName();
            //mengubah nama gambar menjadi nama asli gambar sehingga ketika disimpan ke dalam database data yang masuk adalah nama gambar yang sesungguhnya
            $path = $file->move('assets/',$filename);
            //memasukkan gambar yang diinput ke dalam storage laravel
            $item->productimg = $filename;
        }
        $item->save();
        return redirect('/');
        //update data pada product berdasarkan product id yang dipilih
    }
    
    public function updateProduct($id)
    {
        $list = Category::all();
        $products = Product::where('id', $id)->first();
        return view('updateproduct')->with('products', $products)->with('list', $list);
        //menampilkan view updateproduct
    }

    public function deleteProduct($id)
    {
        $products = Product::find($id);
        $products->delete();
        return redirect('/');
        //delete product berdasarkan product id yang dipilih
    }

    public function productDetail($id)
    {
        $list = Category::all();
        $products = Product::where('id', $id)->first();
        return view('productdetail')->with('products', $products)->with('list', $list);
        //menampilkan detail dari product berdasarkan product id
    }

}
