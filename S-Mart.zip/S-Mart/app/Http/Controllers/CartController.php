<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Cart;
use App\Category;

class CartController extends Controller
{
    public function addtocart(Request $data, $id)
    {   
        $this->validate($data, [
            'quantity' => ['required', 'integer', 'min:1']
        ]);
        //validasi data yang akan di input atau dimasukkan ke dalam cart
        $item = new Cart;
        $item->quantity = $data['quantity'];
        $item->products_id = $id;
        $item->users_id = Auth::id();
        $item->save();
        return redirect('/');
        //function untuk menambahkan data ke dalam cart berdasarkan data yang telah diinput user
    }

    public function cart()
    {
        $mycart = Cart::where('users_id',Auth::id())->get();
        return view('cart')->with('mycart',$mycart);
        //function untuk menampilkan view cart
    }

    public function updatecart(Request $request)
    {
        $this->validate($request, [
            'quantity' => ['required', 'integer', 'min:0']
        ]);
        //validasi data yang akan diinput untuk mengubah data pada cart
        $updated = Cart::where('id', $request->id)->first();
        $updated->quantity = $request->quantity;
        if($updated->quantity == 0)
        {
            $updated->delete();
            //apabila user menginput nilai 0 pada quantity maka cart tersebut akan didelete
        }
        else{
            $updated->save();
            //apabila user menginput nilai selain 0 maka quantity akan di update sesuai nilai yang diinput user
        }
        $mycart = Cart::where('users_id',Auth::id())->get();
        return view('cart')->with('mycart',$mycart);
        //menampilkan view cart
    }
}
