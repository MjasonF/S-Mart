<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Category;

class CategoryController extends Controller
{
    public function category($id)
    {
        $products=Product::where('categories_id',$id)->paginate(8);
        //menampilkan pagination berdasarkan aturan dalam 1 page terdapat 8 item
        $categories=Category::where('id',$id)->first();
        return view('category')->with('products', $products)->with('categories',$categories);
        //menampilkan view category sesuai category id yang dipilih
    }

    public function managecategory(){
        $list = Category::all();
        return view('managecategory')->with('list', $list);
        //menampilkan tampilan managecategory
    }

    public function deletecategory($id){
        $list = Category::find($id);
        $list->delete();
        return redirect('/');
        //menghapus category berdasarkan category id yang dipilih
    }

    public function updatecat(Request $data, $id){
        $this->validate($data, [
            'categoryname' => ['required', 'string', 'min:5'],
            //validasi data yang akan diinput untuk mengubah data pada category
        ]);
        $file = $data['categoryimg'];
        $filename = $file->getClientOriginalName();
        //mengubah nama gambar menjadi nama asli gambar sehingga ketika disimpan ke dalam database data yang masuk adalah nama gambar yang sesungguhnya
        $path = $file->move('assets/',$filename);
        //memasukkan gambar yang diinput ke dalam storage laravel
        $item = Category::find($id);
        $cat = Category::where('categoryname',$data['category'])->first();
        $item->categoryname = $data['categoryname'];
        $item->categoryimg = $filename;
        $item->save();
        return redirect('/');
        //update data pada category berdasarkan category id yang dipilih
    }

    public function updatecategory($id)
    {
        $lists = Category::where('id',$id)->first();
        return view('updatecategory')->with('lists', $lists);
        //menampilkan tampilan updatecategory berdasarkan category id
    }
}
