<?php
   
namespace App\Http\Controllers;
   
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\User;
use Illuminate\Support\Facades\Auth;
  
class PasswordController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
   
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function changepassword()
    {
        return view('changepassword');
    } 
   
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function changepass(Request $request)
    {
        //validasi change password
        if (!(Hash::check($request->get('currentpassword'), Auth::user()->password))) {
            return redirect()->back()->with("error","Your password does not matches.");
            //apabila data password yang diinput tidak sesuai dengan data password yang ada pada database sesuai user
            //menampilkan error message
        }
        if(strcmp($request->get('currentpassword'), $request->get('newpassword')) == 0){
            return redirect()->back()->with("error","New Password cannot be same as your current password.");
            //apabila data password yang diinput sama dengan data password lama yang ada dalam database
            //menampilkan error message
        }
        if(!(strcmp($request->get('newpassword'), $request->get('newconfirm'))) == 0){
            return redirect()->back()->with("error","New Password should be same as your confirmed password.");
            //apabila data password yang telah diinput tidak sama dengan data password baru
            //menampilkan error message
        }
        $user = Auth::user();
        $user->password = bcrypt($request->get('newpassword'));
        $user->save();
        return redirect()->back()->with("success","Password changed successfully !");
        //mengganti password user
    }
}
