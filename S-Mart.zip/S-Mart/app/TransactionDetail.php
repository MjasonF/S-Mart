<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransactionDetail extends Model
{
    protected $table = 'transactiondetails';

    public function detail() {
        return $this->belongsTo('App\Transaction', 'id', 'transactions_id');
    }

    public function products() {
        return $this->hasOne('App\Product', 'id', 'products_id');
    }
}
