<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/', 'HomeController@index')->name('home');
Route::get('/category/{id}', 'CategoryController@category')->name('category');
Route::get('/addproduct', 'ProductController@addProduct')->name('addProduct');
Route::post('/inputproduct', 'ProductController@inputProduct')->name('inputProduct');
Route::get('/updateproduct/{id}', 'ProductController@updateProduct')->name('updateProduct');
Route::post('/updateProduct/{id}', 'ProductController@update')->name('update');
Route::post('/deleteproduct/{id}', 'ProductController@deleteProduct')->name('deleteProduct');
Route::get('/productdetail/{id}', 'ProductController@productDetail')->name('productDetail');
Route::get('/managecategory', 'CategoryController@managecategory')->name('managecategory');
Route::post('/deletecategory/{id}', 'CategoryController@deletecategory')->name('deletecategory');
Route::post('/updatecat/{id}', 'CategoryController@updatecat')->name('updatecat');
Route::get('/updatecategory/{id}', 'CategoryController@updatecategory')->name('updatecategory');
Route::get('/cart', 'CartController@cart')->name('cart');
Route::post('/addtocart/{id}', 'CartController@addtocart')->name('addtocart');
Route::get('/searchproduct/{id}', 'ProductController@searchproduct')->name('searchproduct');
Route::get('/changepassword', 'PasswordController@changepassword')->name('changepassword');
Route::post('/changepass', 'PasswordController@changepass')->name('changepass');
Route::post('/cart', 'CartController@updatecart')->name('updatecart');
Route::get('/transactionhistory', 'TransactionController@transactionhistory')->name('transactionhistory');
Route::post('/createtransaction', 'TransactionController@createtransaction')->name('createtransaction');
Route::get('/transactiondetail/{id}', 'TransactionController@transactiondetail')->middleware('auth')->name('transactiondetail');



